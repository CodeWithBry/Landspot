import { Router } from "express";
import { getAgentListing, createNewListing, getListings } from "../controllers/listings.controllers";
import { requireRole } from "../middleware/roleGuard";
import { requireAuth } from "../middleware/auth.middleware";

const router = Router();

router.get("/get-listings", getListings);
router.post("/add-listing", requireAuth, requireRole('agent'), createNewListing);
router.post("/my-listing", getAgentListing); 

export default router;