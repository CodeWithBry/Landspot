import { Request, Response } from "express";
import { pool } from "../db/db";
import { sendError, sendResponse } from "../utils/response";
import { registerGeocode } from "../services/geocodeService";

export const getListings = async (req: Request, res: Response) => {
    try {
        const result = await pool.query(`SELECT * FROM listings;`);
        sendResponse(res, [...result.rows]);
    } catch (err) {
        console.log(err)
        throw err
    }
}

export const getAgentListing = async (req: Request, res: Response) => {
    const { user } = req.body;
    let query = `
        SELECT * FROM listings WHERE agent_id = $1;
    `
    try {
        const result = await pool.query(query, [user.id])
        sendResponse(res, result.rows)
    } catch (err) {
        console.log(err)
        throw err
    }
}

export const createNewListing = async (req: Request, res: Response) => {
    const { title, description, property_type, price, bedrooms, bathrooms, address } = req.body;
    console.log(req.body)
    try {
        const geo = await registerGeocode(address);
        if (!geo) {
            console.log("ERROR IN GEOCODING!")
            sendError(res, "GEOCODE DIDN'T REGISTERED, TRY A MORE SPECIFIC ADDRESS!")
            return;
        }
        let query = `
            INSERT INTO listings(agent_id, title, description, property_type, price, bedrooms, bathrooms, address, lat, lng)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            RETURNING *;
        `;
        const result = await pool.query(query, [req?.user!.userId, title, description, property_type, price, bedrooms, bathrooms, address, geo.lat, geo.lng]);

        sendResponse(res, result.rows[0])
    } catch (error) {
        console.log("ERROR REVEAL: "+error);
        if (error instanceof Error) sendError(res, error.message);
    }
}